import re
import os

def process_file(file_path):
    host_entries = []
    port_entries = {}
    unique_ip_counts = {}
    unique_port_counts = {}

    with open(file_path, 'r') as file:
        nmap = file.read()

    # Extract hosts and ports
    for line in nmap.split('\n'):
        re_host = re.match(r'Host\: ([0-9.]+?)\s+', line)
        if re_host:
            host = re_host.group(1)
            ports = re.findall('(\d+)\/open', line)

            # Save host entries
            if len(ports):
                host_entries.append((host, ports))

                # Save port entries
                for port in ports:
                    if port in port_entries:
                        port_entries[port].append(host)
                    else:
                        port_entries[port] = [host]

                    # Count unique IPs for each port
                    if port in unique_ip_counts:
                        unique_ip_counts[port].add(host)
                    else:
                        unique_ip_counts[port] = {host}

                    # Count unique ports for each IP
                    if host in unique_port_counts:
                        unique_port_counts[host].add(port)
                    else:
                        unique_port_counts[host] = {port}

    # Output directory for hosts
    host_output_directory = 'host_outputs'
    if not os.path.exists(host_output_directory):
        os.makedirs(host_output_directory)

    # Write host files
    for host, ports in host_entries:
        host_output_file_path = os.path.join(host_output_directory, f'host_{host}.txt')
        with open(host_output_file_path, 'w') as output_file:
            output_file.write('{}\n'.format(ports))

    # Output directory for ports
    port_output_directory = 'port_outputs'
    if not os.path.exists(port_output_directory):
        os.makedirs(port_output_directory)

    # Write port files
    for port, hosts in sorted(port_entries.items()):
        port_output_file_path = os.path.join(port_output_directory, f'port_{port}.txt')
        with open(port_output_file_path, 'w') as output_file:
            for host in hosts:
                output_file.write(f'{host}\n')

    print(f"Output files written to {host_output_directory} and {port_output_directory}")


    # Print unique counts for each port within the IP text files
    #print("\nUnique IP counts for each port within the IP text files:")
    #for port, unique_ips in sorted(unique_ip_counts.items()):
    #    print(f"Port {port}: {len(unique_ips)}")

    print("\nUnique IP counts for each port within the IP text files:")
    for port, unique_ips in sorted(unique_ip_counts.items(), key=lambda x: int(x[0])):
        print(f"Port {port}: {len(unique_ips)}")

    #print("\nUnique IP counts for each port within the IP text files:")
    #for port, unique_ips in unique_ip_counts.items():
    #	print(f"Port {port}: {len(unique_ips)}")

    # Print unique counts for each IP within the port text files
    print("\nUnique port counts for each IP within the port text files:")
    for host, unique_ports in unique_port_counts.items():
        print(f"IP {host}: {len(unique_ports)}")

# Prompt user for file path
file_path = input("Enter the path to the file (e.g., testing.gnmap): ")
process_file(file_path)
